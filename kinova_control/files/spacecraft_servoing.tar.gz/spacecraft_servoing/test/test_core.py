"""ROS-free unit tests:  python3 -m pytest test/ -q"""
import math
import os

import cv2
import numpy as np

from spacecraft_servoing.geometry import inv_T, pose_to_T, project, transform
from spacecraft_servoing.mission_fsm import Inputs, MissionFSM, State
from spacecraft_servoing.model_tracker import load_cao_polylines
from spacecraft_servoing.refiners import ScrewHeadRefiner
from spacecraft_servoing.targets import load_targets

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
K = np.array([[554.25, 0, 320.5], [0, 554.25, 240.5], [0, 0, 1]])
_, TARGETS = load_targets(os.path.join(ROOT, 'config', 'targets.yaml'))


def test_desired_features_centered_and_scaled():
    t = TARGETS['screw_1']
    sd = t.desired_features(t.standoff)
    assert np.allclose(sd[0, :2], 0.0) and np.allclose(sd[:, 2], t.standoff)
    assert np.allclose(np.hypot(sd[1:, 0], sd[1:, 1]), 0.03 / t.standoff)


def test_features_match_when_camera_at_desired_pose():
    for t in TARGETS.values():
        yaw = 0.7
        cMo = t.cdMf(t.standoff, yaw) @ inv_T(t.oMf)       # camera exactly at the goal
        P = transform(cMo @ t.oMf, t.points_f)
        _, xy, Z = project(P, K)
        sd = t.desired_features(t.standoff, yaw)
        assert np.allclose(xy, sd[:, :2]) and np.allclose(Z, sd[:, 2])
        cMf = cMo @ t.oMf
        assert np.dot(cMf[:3, 2], cMf[:3, 3]) < 0          # surface faces the camera


def test_best_yaw_uses_symmetry():
    t = TARGETS['screw_2']
    cMo = t.cdMf(0.3, math.radians(100)) @ inv_T(t.oMf)
    assert abs(math.degrees(t.best_yaw(cMo)) - 90.0) < 1e-6
    p = TARGETS['solar_panel']
    cMo = p.cdMf(0.5, math.radians(170)) @ inv_T(p.oMf)
    assert abs(math.degrees(p.best_yaw(cMo)) - 180.0) < 1e-6


def test_fsm_full_cycle_and_switch():
    fsm = MissionFSM(TARGETS)
    def run(n, **kw):
        base = dict(robot_ready=True, homed=True, tracking_ok=True, feature_err_px=1.0, dt=0.1)
        base.update(kw)
        for _ in range(n):
            cmd = fsm.step(Inputs(**base))
        return cmd
    assert fsm.step(Inputs(True, False, False)).mode == 'home'
    assert run(1, homed=False).mode == 'none' and fsm.state == State.HOMING
    run(1); assert fsm.state == State.ACQUIRE
    assert run(1, tracking_ok=False).mode == 'reinit'
    run(12); assert fsm.state == State.IDLE
    ok, _ = fsm.request('nope'); assert not ok
    fsm.request('screw_1')
    cmd = run(1); assert fsm.state == State.APPROACH and cmd.standoff == 0.30
    run(12); assert fsm.state == State.ALIGN
    run(200); assert fsm.state == State.HOLD and abs(fsm.z_ref - 0.15) < 1e-9
    fsm.request('solar_panel')
    run(1); assert fsm.state == State.RETREAT
    run(45); assert fsm.state == State.APPROACH and fsm.current == 'solar_panel'  # 30 ramp + 10 settle
    assert run(1, tracking_ok=False).mode == 'hold' and fsm.state == State.LOST
    run(6, tracking_ok=False); assert fsm.state == State.ACQUIRE
    run(12); assert fsm.state == State.APPROACH and fsm.current == 'solar_panel'
    fsm.request('abort'); run(300)
    assert fsm.state == State.IDLE and fsm.current is None


def test_cao_parse_and_outward_normals():
    pts, polys = load_cao_polylines(os.path.join(ROOT, 'models', 'mock_spacecraft', 'spacecraft.cao'))
    assert pts.shape == (20, 3) and len(polys) == 13
    boxes = [(0, polys[:6]), (12, polys[7:])]
    for base, faces in boxes:
        ctr = pts[base:base + 8].mean(axis=0)
        for f in faces:
            a, b, c = pts[f[:3]]
            n = np.cross(b - a, c - b)
            assert np.dot(n, pts[f].mean(axis=0) - ctr) > 0


def test_screw_refiner_recovers_offset():
    t = TARGETS['screw_1']
    img = np.full((480, 640), 180, np.uint8)
    true_c = np.array([330.0, 250.0])
    Z = np.full(len(t.points_f), 0.15)
    r = K[0, 0] * t.params['head_radius'] / 0.15
    cv2.circle(img, (int(true_c[0]), int(true_c[1])), int(round(r)), 30, -1, lineType=cv2.LINE_AA)
    uv = np.array([[322.0, 244.0], [400, 244], [322, 320], [250, 244], [322, 170]])
    out = ScrewHeadRefiner().refine(img, uv, t, K, Z)
    assert out is not None and np.linalg.norm(out[0] - true_c) < 1.5
    assert np.allclose(out - uv, out[0] - uv[0])
