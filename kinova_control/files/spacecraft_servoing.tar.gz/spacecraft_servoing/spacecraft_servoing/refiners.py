"""
Local refinement of model-projected features.

The model tracker gives a global pose; small parts (a screw head) can be a
few pixels off because of CAD tolerances or tracking drift. A refiner
searches only a small ROI around the projection -> robust and cheap.

Each refiner takes (gray, uv Nx2 projected, target, K, Z) and returns the
refined uv (Nx2) or None if not confident (the node then uses the model
projection unchanged). Replace/extend these with learned detectors later.
"""
import cv2
import numpy as np


class NoRefiner:
    name = 'none'

    def refine(self, gray, uv, target, K, Z):
        return None


class ScrewHeadRefiner:
    """Hough circle in a ROI around the projected screw centre (point 0).
    The measured offset is applied to all target points (virtual ring)."""
    name = 'screw_hough'

    def __init__(self, roi_scale=3.0, max_shift_px=15.0, min_radius_px=4.0):
        self.roi_scale = roi_scale
        self.max_shift = max_shift_px
        self.min_r = min_radius_px

    def refine(self, gray, uv, target, K, Z):
        r_px = K[0, 0] * target.params.get('head_radius', 0.005) / max(float(Z[0]), 1e-3)
        if r_px < self.min_r:
            return None                                     # too far: trust the model
        h, w = gray.shape[:2]
        cu, cv_ = uv[0]
        half = int(max(r_px * self.roi_scale, r_px + self.max_shift))
        x0, y0 = int(cu) - half, int(cv_) - half
        x1, y1 = x0 + 2 * half, y0 + 2 * half
        if x0 < 0 or y0 < 0 or x1 > w or y1 > h:
            return None
        roi = cv2.GaussianBlur(gray[y0:y1, x0:x1], (5, 5), 1.2)
        circles = cv2.HoughCircles(roi, cv2.HOUGH_GRADIENT, dp=1.0, minDist=r_px,
                                   param1=80, param2=max(8, int(0.6 * r_px)),
                                   minRadius=int(0.7 * r_px), maxRadius=int(1.4 * r_px) + 1)
        if circles is None:
            return None
        c = circles[0]
        centres = c[:, :2] + [x0, y0]
        d = np.linalg.norm(centres - uv[0], axis=1)
        k = int(np.argmin(d))
        if d[k] > self.max_shift:
            return None
        return uv + (centres[k] - uv[0])


class CornerRefiner:
    """Sub-pixel corner refinement of each projected corner (e.g. panel frame)."""
    name = 'corner_subpix'

    def __init__(self, win=7, max_shift_px=6.0):
        self.win = win
        self.max_shift = max_shift_px

    def refine(self, gray, uv, target, K, Z):
        h, w = gray.shape[:2]
        m = self.win + 2
        if np.any(uv[:, 0] < m) or np.any(uv[:, 0] > w - m) or np.any(uv[:, 1] < m) or np.any(uv[:, 1] > h - m):
            return None
        pts = uv.astype(np.float32).reshape(-1, 1, 2).copy()
        crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.01)
        cv2.cornerSubPix(gray, pts, (self.win, self.win), (-1, -1), crit)
        out = pts.reshape(-1, 2).astype(float)
        if np.any(np.linalg.norm(out - uv, axis=1) > self.max_shift):
            return None
        return out


def make_refiner(kind, enabled=True):
    if not enabled:
        return NoRefiner()
    return {'screw': ScrewHeadRefiner, 'planar_region': CornerRefiner}.get(kind, NoRefiner)()
