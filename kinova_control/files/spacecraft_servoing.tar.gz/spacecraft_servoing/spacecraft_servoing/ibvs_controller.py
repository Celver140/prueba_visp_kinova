"""
IBVS control law (ViSP vpServo, eye-in-hand) on N point features.

Input : current s = (x, y, Z) and desired s* = (x*, y*, Z*) for N points,
        normalized image coordinates, depths from the model pose.
Output: camera twist (vx, vy, vz, wx, wy, wz) in the OPTICAL frame.
"""
import math

import numpy as np

from .model_tracker import resolve_enum


def _to_np(v):
    try:
        return np.array(v, dtype=float).ravel()
    except Exception:
        return np.array([v[i] for i in range(v.getRows())], dtype=float)


class IBVSController:

    def __init__(self, lambda_0=1.0, lambda_inf=0.4, lambda_slope=5.0,
                 v_max=0.08, w_max=0.4, interaction='mean'):
        from visp.visual_features import FeaturePoint
        from visp.vs import Servo
        self._Servo, self._FP = Servo, FeaturePoint
        self.l0, self.linf, self.slope = lambda_0, lambda_inf, lambda_slope
        self.v_max, self.w_max = v_max, w_max
        self._eih = resolve_enum(Servo, 'EYEINHAND_CAMERA', 'ServoType.EYEINHAND_CAMERA',
                                 'vpServoType.EYEINHAND_CAMERA')
        cur = resolve_enum(Servo, 'CURRENT', 'ServoIteractionMatrixType.CURRENT',
                           'vpServoIteractionMatrixType.CURRENT')
        mean = resolve_enum(Servo, 'MEAN', 'ServoIteractionMatrixType.MEAN',
                            'vpServoIteractionMatrixType.MEAN')
        self._pinv = resolve_enum(Servo, 'PSEUDO_INVERSE', 'ServoInversionType.PSEUDO_INVERSE',
                                  'vpServoInversionType.PSEUDO_INVERSE')
        self._itype = mean if (interaction == 'mean' and mean is not None) else cur
        if None in (self._eih, self._itype, self._pinv):
            raise RuntimeError('Could not resolve vpServo enums in these ViSP bindings.')
        self.n = 0
        self.task = None

    def reset(self, n_points):
        """(Re)build the task for n points (call when the target changes)."""
        self.task = self._Servo()
        self.task.setServo(self._eih)
        self.task.setInteractionMatrixType(self._itype, self._pinv)
        self.s = [self._FP() for _ in range(n_points)]
        self.sd = [self._FP() for _ in range(n_points)]
        for a, b in zip(self.s, self.sd):
            a.buildFrom(0.0, 0.0, 1.0)
            b.buildFrom(0.0, 0.0, 1.0)
            self.task.addFeature(a, b)
        self.n = n_points

    def gain(self, e_norm):
        if self.l0 <= self.linf:
            return self.l0
        return (self.l0 - self.linf) * math.exp(-self.slope * e_norm / (self.l0 - self.linf)) + self.linf

    def compute(self, s, sd, gain_scale=1.0):
        """s, sd: Nx3 (x, y, Z). Returns (twist 6, error vector 2N) or (None, err) if invalid."""
        s = np.asarray(s, dtype=float)
        sd = np.asarray(sd, dtype=float)
        if s.shape[0] != self.n:
            self.reset(s.shape[0])
        err = np.concatenate([s[:, 0] - sd[:, 0], s[:, 1] - sd[:, 1]])
        if not (np.all(np.isfinite(s)) and np.all(np.isfinite(sd))) or np.any(s[:, 2] <= 0) or np.any(sd[:, 2] <= 0):
            return None, err
        self.task.setLambda(gain_scale * self.gain(float(np.linalg.norm(err))))
        for i in range(self.n):
            self.s[i].buildFrom(float(s[i, 0]), float(s[i, 1]), float(s[i, 2]))
            self.sd[i].buildFrom(float(sd[i, 0]), float(sd[i, 1]), float(sd[i, 2]))
        try:
            v = _to_np(self.task.computeControlLaw())[:6]
        except Exception:
            return None, err
        if v.size < 6 or not np.all(np.isfinite(v)):
            return None, err
        tn, rn = np.linalg.norm(v[:3]), np.linalg.norm(v[3:])
        if tn > self.v_max:
            v[:3] *= self.v_max / tn
        if rn > self.w_max:
            v[3:] *= self.w_max / rn
        return v, err
