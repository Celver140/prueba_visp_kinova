"""Small rigid-body helpers (numpy only). Convention: aMb maps points from b to a."""
import math

import numpy as np


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


def rot_y(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])


def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def rpy_to_R(roll, pitch, yaw):
    """URDF/SDF convention: R = Rz(yaw) Ry(pitch) Rx(roll)."""
    return rot_z(yaw) @ rot_y(pitch) @ rot_x(roll)


def make_T(R=None, t=None):
    T = np.eye(4)
    if R is not None:
        T[:3, :3] = R
    if t is not None:
        T[:3, 3] = np.asarray(t, dtype=float).reshape(3)
    return T


def pose_to_T(xyz, rpy):
    return make_T(rpy_to_R(*rpy), xyz)


def inv_T(T):
    Ti = np.eye(4)
    Ti[:3, :3] = T[:3, :3].T
    Ti[:3, 3] = -T[:3, :3].T @ T[:3, 3]
    return Ti


def transform(T, P):
    """Apply 4x4 T to Nx3 points."""
    P = np.asarray(P, dtype=float).reshape(-1, 3)
    return P @ T[:3, :3].T + T[:3, 3]


def rotation_angle(R):
    return math.acos(float(np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0)))


def project(P_c, K):
    """Nx3 camera-frame points -> (uv Nx2, xy Nx2 normalized, Z N). Assumes Z > 0."""
    Z = P_c[:, 2]
    xy = P_c[:, :2] / Z[:, None]
    uv = np.stack([K[0, 0] * xy[:, 0] + K[0, 2], K[1, 1] * xy[:, 1] + K[1, 2]], axis=1)
    return uv, xy, Z
