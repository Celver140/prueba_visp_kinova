"""
ViSP model-based tracking (vpMbGenericTracker) of the whole spacecraft.

The tracker gives cMo (camera <- spacecraft model). Every target's features
are then obtained by projecting CAD-known points -> the same pose serves all
targets, and features stay defined even when they are small, occluded or
slightly outside the image.
"""
import math

import numpy as np


def resolve_enum(cls, *paths):
    """pybind11 may expose enum values on the class or on a nested enum type."""
    for path in paths:
        obj = cls
        try:
            for part in path.split('.'):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    return None


# ----------------------------------------------------------------------
# .cao parsing (only for drawing / sanity checks; ViSP loads the file itself)
# ----------------------------------------------------------------------
def load_cao_polylines(path):
    """Returns (points Nx3, list of index lists) for faces-from-points,
    faces-from-lines and standalone lines of a ViSP .cao (V1) file."""
    with open(path, 'r') as f:
        toks = []
        for line in f:
            line = line.split('#', 1)[0].strip()
            if line:
                toks.append(line.split())
    it = iter(toks)
    head = next(it)
    if head[0] != 'V1':
        raise ValueError(f'{path}: expected V1 header')

    def nxt():
        return next(it)

    n_pts = int(nxt()[0])
    pts = np.array([[float(v) for v in nxt()[:3]] for _ in range(n_pts)])
    n_lines = int(nxt()[0])
    lines = [tuple(int(v) for v in nxt()[:2]) for _ in range(n_lines)]
    polys = []
    n_fl = int(nxt()[0])
    for _ in range(n_fl):
        row = nxt()
        idx = [int(v) for v in row[1:1 + int(row[0])]]
        chain = []
        for li in idx:
            a, b = lines[li]
            chain += [a, b]
        polys.append(chain)
    n_fp = int(nxt()[0])
    for _ in range(n_fp):
        row = nxt()
        polys.append([int(v) for v in row[1:1 + int(row[0])]])
    used = {i for p in polys for i in p}
    polys += [list(l) for l in lines if not (l[0] in used and l[1] in used)]
    return pts, polys


class ModelTracker:

    def __init__(self, K, cao_path, use_klt=False, me_range=10, me_threshold=20.0,
                 me_sample_step=4, max_projection_error_deg=45.0, logger=None):
        from visp.core import CameraParameters, HomogeneousMatrix, ImageGray
        from visp.mbt import MbGenericTracker
        from visp.me import Me

        self._ImageGray, self._HM = ImageGray, HomogeneousMatrix
        self.log = logger or (lambda m: None)
        self.max_err = max_projection_error_deg
        self.ok = False
        self.last_err = float('nan')
        self.cMo = None

        edge = resolve_enum(MbGenericTracker, 'EDGE_TRACKER', 'TrackerType.EDGE_TRACKER', 'vpTrackerType.EDGE_TRACKER')
        klt = resolve_enum(MbGenericTracker, 'KLT_TRACKER', 'TrackerType.KLT_TRACKER', 'vpTrackerType.KLT_TRACKER')
        ttype, self.mode = edge, 'edge'
        if use_klt and edge is not None and klt is not None:
            try:
                ttype, self.mode = int(edge) | int(klt), 'edge+klt'
            except Exception:
                self.log('KLT requested but tracker types cannot be combined; using edges only.')
        try:
            self.tracker = MbGenericTracker(ttype) if ttype is not None else MbGenericTracker()
        except Exception:
            self.tracker, self.mode = MbGenericTracker(), 'edge (default ctor)'

        me = Me()
        for fn, arg in (('setMaskSize', 5), ('setMaskNumber', 180), ('setRange', int(me_range)),
                        ('setSampleStep', float(me_sample_step)), ('setMu1', 0.5), ('setMu2', 0.5)):
            try:
                getattr(me, fn)(arg)
            except Exception:
                pass
        nt = resolve_enum(Me, 'NORMALIZED_THRESHOLD', 'LikelihoodThresholdType.NORMALIZED_THRESHOLD',
                          'vpLikelihoodThresholdType.NORMALIZED_THRESHOLD')
        self.me_info = 'ViSP default threshold'
        if nt is not None:
            try:
                me.setLikelihoodThresholdType(nt)
                me.setThreshold(float(me_threshold))
                self.me_info = f'normalized threshold {me_threshold}'
            except Exception:
                pass
        self.tracker.setMovingEdge(me)

        if 'klt' in self.mode:
            try:
                from visp.klt import KltOpencv
                klt_s = KltOpencv()
                klt_s.setMaxFeatures(300)
                klt_s.setWindowSize(5)
                klt_s.setQuality(0.015)
                klt_s.setMinDistance(8)
                klt_s.setHarrisFreeParameter(0.01)
                klt_s.setBlockSize(3)
                klt_s.setPyramidLevels(3)
                self.tracker.setKltOpencv(klt_s)
                self.tracker.setKltMaskBorder(5)
            except Exception as e:
                self.log(f'KLT settings not applied ({e}); tracker keeps its defaults.')

        cam = CameraParameters()
        cam.initPersProjWithoutDistortion(float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
        self.tracker.setCameraParameters(cam)
        self.tracker.loadModel(cao_path)
        for fn, arg in (('setDisplayFeatures', False), ('setProjectionErrorComputation', True),
                        ('setAngleAppear', math.radians(70.0)), ('setAngleDisappear', math.radians(80.0)),
                        ('setNearClippingDistance', 0.05), ('setFarClippingDistance', 5.0)):
            try:
                getattr(self.tracker, fn)(arg)
            except Exception:
                pass
        self.model_points, self.model_polys = load_cao_polylines(cao_path)

    # ------------------------------------------------------------------
    def _img(self, gray):
        gray = np.ascontiguousarray(gray, dtype=np.uint8)
        try:
            return self._ImageGray(gray)
        except Exception:
            I = self._ImageGray()
            I.resize(gray.shape[0], gray.shape[1])
            np.asarray(I.numpy())[:, :] = gray
            return I

    def _hm(self, T):
        import cv2
        rvec, _ = cv2.Rodrigues(np.asarray(T[:3, :3], dtype=float))
        t = T[:3, 3]
        try:
            return self._HM(*map(float, t), *map(float, rvec.ravel()))
        except Exception:
            from visp.core import ThetaUVector, TranslationVector
            return self._HM(TranslationVector(*map(float, t)), ThetaUVector(*map(float, rvec.ravel())))

    @staticmethod
    def _np(M):
        try:
            return np.array(M.numpy(), dtype=float).reshape(4, 4)
        except Exception:
            return np.array([[M[i, j] for j in range(4)] for i in range(4)], dtype=float)

    # ------------------------------------------------------------------
    def init(self, gray, cMo):
        """(Re)initialise from a 4x4 pose guess."""
        self.tracker.initFromPose(self._img(gray), self._hm(cMo))
        self.cMo = np.array(cMo, dtype=float)
        self.ok = True

    def track(self, gray):
        """Returns 4x4 cMo or None (ok becomes False)."""
        if not self.ok:
            return None
        try:
            self.tracker.track(self._img(gray))
            T = self._np(self.tracker.getPose())
        except Exception as e:
            self.log(f'tracker exception: {e}')
            self.ok = False
            return None
        try:
            self.last_err = float(self.tracker.getProjectionError())
        except Exception:
            self.last_err = float('nan')
        if not np.all(np.isfinite(T)) or T[2, 3] <= 0.0 or \
                (np.isfinite(self.last_err) and self.last_err > self.max_err):
            self.ok = False
            return None
        self.cMo = T
        return T
