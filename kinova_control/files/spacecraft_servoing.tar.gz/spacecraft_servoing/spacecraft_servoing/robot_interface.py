"""
Robot side: joint states, URDF -> KDL chain (base -> camera), camera pose,
optical twist -> joint velocities (damped least squares), command output
(joint_trajectory_controller in sim; a velocity/twist controller later).
"""
import numpy as np
import PyKDL as kdl
from builtin_interfaces.msg import Duration
from control_msgs.action import FollowJointTrajectory
from rclpy.action import ActionClient
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray, String
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from urdf_parser_py.urdf import URDF as UrdfModel

from .geometry import make_T

# optical (Z fwd, X right, Y down) -> Gazebo Classic sensor link (X fwd, Y left, Z up)
R_LINK_OPT = np.array([[0.0, 0.0, 1.0], [-1.0, 0.0, 0.0], [0.0, -1.0, 0.0]])


def _fixed_joint(name):
    try:
        return kdl.Joint(name)
    except TypeError:
        pass
    for attr in ('Fixed', 'None'):
        try:
            return kdl.Joint(name, getattr(kdl.Joint, attr))
        except (AttributeError, TypeError):
            continue
    raise RuntimeError('Cannot build a fixed PyKDL.Joint')


def build_chain(urdf_xml, base, tip):
    robot = UrdfModel.from_xml_string(urdf_xml)
    chain = kdl.Chain()
    for jn in robot.get_chain(base, tip, links=False, joints=True):
        j = robot.joint_map[jn]
        o = j.origin
        F = kdl.Frame(kdl.Rotation.RPY(*(o.rpy if o is not None and o.rpy else [0.0] * 3)),
                      kdl.Vector(*(o.xyz if o is not None and o.xyz else [0.0] * 3)))
        axis = j.axis if j.axis else [1.0, 0.0, 0.0]
        if j.type in ('revolute', 'continuous'):
            kj = kdl.Joint(j.name, F.p, F.M * kdl.Vector(*axis), kdl.Joint.RotAxis)
        elif j.type == 'prismatic':
            kj = kdl.Joint(j.name, F.p, F.M * kdl.Vector(*axis), kdl.Joint.TransAxis)
        else:
            kj = _fixed_joint(j.name)
        chain.addSegment(kdl.Segment(j.child, kj, F))
    return chain


class RobotInterface:

    def __init__(self, node, joint_names, base_link='base_link', camera_frame='',
                 camera_convention='gazebo_link', command_mode='trajectory',
                 trajectory_topic='/joint_trajectory_controller/joint_trajectory',
                 velocity_topic='/forward_velocity_controller/commands',
                 action_name='/joint_trajectory_controller/follow_joint_trajectory',
                 min_horizon=0.1, qdot_max=0.5, dls_eps=0.05, dls_lambda_max=0.05):
        self.node = node
        self.joint_names = list(joint_names)
        self.n = len(self.joint_names)
        self.base = base_link
        self.cam_frame = camera_frame or None
        self.convention = camera_convention
        self.command_mode = command_mode
        self.min_horizon = min_horizon
        self.horizon = min_horizon
        self.qdot_max = qdot_max
        self.dls_eps, self.dls_lmax = dls_eps, dls_lambda_max
        self.q = np.zeros(self.n)
        self.have_js = False
        self.urdf = None
        self.chain = None
        self.homed = False
        self._home_sent = False

        latched = QoSProfile(reliability=ReliabilityPolicy.RELIABLE, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                             history=HistoryPolicy.KEEP_LAST, depth=1)
        node.create_subscription(JointState, '/joint_states', self._js_cb, 10)
        node.create_subscription(String, '/robot_description', self._urdf_cb, latched)
        self.traj_pub = node.create_publisher(JointTrajectory, trajectory_topic, 10)
        self.vel_pub = node.create_publisher(Float64MultiArray, velocity_topic, 10)
        self.action = ActionClient(node, FollowJointTrajectory, action_name)

    # ---------------- state ----------------
    def _js_cb(self, msg):
        for i, name in enumerate(self.joint_names):
            if name in msg.name:
                self.q[i] = msg.position[msg.name.index(name)]
        self.have_js = True

    def _urdf_cb(self, msg):
        if self.urdf is None:
            self.urdf = msg.data
            self._build()

    def set_camera_frame(self, frame_id):
        if self.cam_frame is None and frame_id:
            self.cam_frame = frame_id
            self.node.get_logger().info(f"camera frame from image header: '{frame_id}'")
            self._build()

    def _build(self):
        if self.chain is not None or self.urdf is None or self.cam_frame is None:
            return
        try:
            chain = build_chain(self.urdf, self.base, self.cam_frame)
        except Exception as e:
            self.node.get_logger().error(f'KDL chain {self.base}->{self.cam_frame} failed: {e}')
            return
        if chain.getNrOfJoints() != self.n:
            self.node.get_logger().error(f'chain has {chain.getNrOfJoints()} joints, expected {self.n}')
            return
        self.chain = chain
        self.jac_solver = kdl.ChainJntToJacSolver(chain)
        self.fk_solver = kdl.ChainFkSolverPos_recursive(chain)
        self.node.get_logger().info(f'KDL chain ready: {self.base} -> {self.cam_frame}')

    def ready(self):
        return self.have_js and self.chain is not None and self.action.server_is_ready()

    def _qkdl(self):
        q = kdl.JntArray(self.n)
        for i in range(self.n):
            q[i] = float(self.q[i])
        return q

    # ---------------- kinematics ----------------
    def _R_link_opt(self):
        return R_LINK_OPT if self.convention == 'gazebo_link' else np.eye(3)

    def camera_pose(self):
        """4x4 bMc of the OPTICAL camera frame."""
        f = kdl.Frame()
        self.fk_solver.JntToCart(self._qkdl(), f)
        R = np.array([[f.M[i, j] for j in range(3)] for i in range(3)])
        return make_T(R @ self._R_link_opt(), [f.p[0], f.p[1], f.p[2]])

    def twist_to_qdot(self, v_opt):
        Rlo = self._R_link_opt()
        v_link = np.concatenate([Rlo @ v_opt[:3], Rlo @ v_opt[3:]])
        q = self._qkdl()
        jac = kdl.Jacobian(self.n)
        self.jac_solver.JntToJac(q, jac)
        f = kdl.Frame()
        self.fk_solver.JntToCart(q, f)
        R = np.array([[f.M[i, j] for j in range(3)] for i in range(3)])
        v_base = np.concatenate([R @ v_link[:3], R @ v_link[3:]])
        J = np.array([[jac[i, j] for j in range(self.n)] for i in range(6)])
        if not (np.all(np.isfinite(J)) and np.all(np.isfinite(v_base))):
            return np.zeros(self.n)
        U, S, Vt = np.linalg.svd(J, full_matrices=False)
        smin = S[-1]
        lam2 = 0.0 if smin >= self.dls_eps else (1.0 - (smin / self.dls_eps) ** 2) * self.dls_lmax ** 2
        qdot = Vt.T @ np.diag(S / (S ** 2 + lam2)) @ U.T @ v_base
        m = float(np.max(np.abs(qdot)))
        return qdot * (self.qdot_max / m) if m > self.qdot_max else qdot

    # ---------------- commands ----------------
    def set_period(self, dt):
        self.horizon = max(self.min_horizon, 2.0 * dt)

    def command_twist(self, v_opt):
        self.send_qdot(self.twist_to_qdot(np.asarray(v_opt, dtype=float)))

    def hold(self):
        self.send_qdot(np.zeros(self.n))

    def send_qdot(self, qdot):
        if self.command_mode == 'velocity':
            self.vel_pub.publish(Float64MultiArray(data=[float(x) for x in qdot]))
            return
        msg = JointTrajectory()
        msg.joint_names = self.joint_names
        pt = JointTrajectoryPoint()
        h = self.horizon
        pt.positions = [float(self.q[i] + qdot[i] * h) for i in range(self.n)]
        pt.time_from_start = Duration(sec=int(h), nanosec=int((h - int(h)) * 1e9))
        msg.points = [pt]
        self.traj_pub.publish(msg)

    def send_home(self, positions, duration_s):
        if self._home_sent:
            return
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = self.joint_names
        pt = JointTrajectoryPoint()
        pt.positions = [float(p) for p in positions]
        pt.time_from_start = Duration(sec=int(duration_s))
        goal.trajectory.points = [pt]
        self._home_sent = True
        self.action.send_goal_async(goal).add_done_callback(self._home_resp)
        self.node.get_logger().info('moving to home pose...')

    def _home_resp(self, fut):
        handle = fut.result()
        if not handle.accepted:
            self.node.get_logger().error('home trajectory rejected')
            self._home_sent = False
            return
        handle.get_result_async().add_done_callback(lambda _: setattr(self, 'homed', True))
