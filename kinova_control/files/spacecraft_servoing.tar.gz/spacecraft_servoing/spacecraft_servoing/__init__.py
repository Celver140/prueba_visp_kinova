"""Model-based IBVS for on-orbit servicing (Kinova Gen3 + ViSP)."""
