import os
from glob import glob

from setuptools import find_packages, setup

package_name = 'spacecraft_servoing'

data_files = [
    ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
    ('share/' + package_name, ['package.xml']),
    ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ('share/' + package_name + '/config', glob('config/*.yaml')),
]
# install models/ keeping the folder structure (Gazebo model:// + ViSP .cao files)
for f in glob('models/**/*', recursive=True):
    if os.path.isfile(f):
        data_files.append((os.path.join('share', package_name, os.path.dirname(f)), [f]))

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=data_files,
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='huro',
    maintainer_email='huro@todo.todo',
    description='Model-based IBVS (ViSP) for on-orbit servicing targets',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'servoing_node = spacecraft_servoing.servoing_node:main',
        ],
    },
)
