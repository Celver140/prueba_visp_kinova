#!/usr/bin/env python3
"""
Generates a consistent MOCK spacecraft from one geometric description:
  models/mock_spacecraft/model.sdf + model.config   (Gazebo Classic visual)
  models/mock_spacecraft/spacecraft.cao            (ViSP tracking model)
  config/targets.yaml                              (servicing targets)

Model frame o: centre of the bus bottom face, +Z up (servicing face = top).
Run from the package root:  python3 tools/make_mock_spacecraft.py
Replace with your Inventor model later (see models/README.md).
"""
import os

import yaml

BUS = dict(size=(0.25, 0.25, 0.20), center=(0.0, 0.0, 0.10))
PLATE = dict(size=(0.12, 0.12, 0.003), center=(0.0, 0.0, 0.2015))          # access plate on top
SCREW_R, SCREW_H = 0.006, 0.004
SCREW_XY = [(0.045, 0.045), (-0.045, 0.045), (-0.045, -0.045), (0.045, -0.045)]
SCREW_Z = PLATE['center'][2] + PLATE['size'][2] / 2 + SCREW_H / 2               # cylinder centre
BOOM = dict(size=(0.02, 0.08, 0.02), center=(0.0, 0.165, 0.15))
PANEL = dict(size=(0.30, 0.15, 0.006), center=(0.0, 0.28, 0.15))

COLORS = {'bus': (0.80, 0.60, 0.10), 'plate': (0.70, 0.70, 0.72), 'screw': (0.08, 0.08, 0.08),
          'boom': (0.50, 0.50, 0.50), 'panel': (0.05, 0.10, 0.35)}


def material(rgb):
    r, g, b = rgb
    return (f'<material><ambient>{r} {g} {b} 1</ambient><diffuse>{r} {g} {b} 1</diffuse>'
            f'<specular>0.2 0.2 0.2 1</specular></material>')


def box_visual(name, part, color):
    (sx, sy, sz), (x, y, z) = part['size'], part['center']
    return (f'      <visual name="{name}"><pose>{x} {y} {z} 0 0 0</pose>'
            f'<geometry><box><size>{sx} {sy} {sz}</size></box></geometry>{material(COLORS[color])}</visual>\n'
            f'      <collision name="{name}_col"><pose>{x} {y} {z} 0 0 0</pose>'
            f'<geometry><box><size>{sx} {sy} {sz}</size></box></geometry></collision>\n')


def write_sdf(path):
    v = box_visual('bus', BUS, 'bus') + box_visual('access_plate', PLATE, 'plate')
    v += box_visual('boom', BOOM, 'boom') + box_visual('solar_panel', PANEL, 'panel')
    for i, (x, y) in enumerate(SCREW_XY, 1):
        v += (f'      <visual name="screw_{i}"><pose>{x} {y} {SCREW_Z} 0 0 0</pose>'
              f'<geometry><cylinder><radius>{SCREW_R}</radius><length>{SCREW_H}</length></cylinder>'
              f'</geometry>{material(COLORS["screw"])}</visual>\n')
    sdf = ('<?xml version="1.0"?>\n<sdf version="1.6">\n  <model name="mock_spacecraft">\n'
           '    <static>true</static>\n    <link name="body">\n'
           '      <inertial><mass>10.0</mass></inertial>\n' + v + '    </link>\n  </model>\n</sdf>\n')
    with open(path, 'w') as f:
        f.write(sdf)


def write_config(path):
    with open(path, 'w') as f:
        f.write('<?xml version="1.0"?>\n<model>\n  <name>mock_spacecraft</name>\n  <version>1.0</version>\n'
                '  <sdf version="1.6">model.sdf</sdf>\n  <description>Mock servicing target</description>\n'
                '</model>\n')


class Cao:
    def __init__(self):
        self.pts, self.faces = [], []

    def box(self, part):
        (sx, sy, sz), (cx, cy, cz) = part['size'], part['center']
        hx, hy, hz = sx / 2, sy / 2, sz / 2
        b = len(self.pts)
        self.pts += [(cx - hx, cy - hy, cz + hz), (cx + hx, cy - hy, cz + hz), (cx + hx, cy + hy, cz + hz),
                     (cx - hx, cy + hy, cz + hz), (cx - hx, cy - hy, cz - hz), (cx + hx, cy - hy, cz - hz),
                     (cx + hx, cy + hy, cz - hz), (cx - hx, cy + hy, cz - hz)]
        # counter-clockwise seen from outside (outward normals)
        for f in [(0, 1, 2, 3), (4, 7, 6, 5), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)]:
            self.faces.append([b + i for i in f])

    def top_rectangle(self, part):
        (sx, sy, sz), (cx, cy, cz) = part['size'], part['center']
        z, hx, hy = cz + sz / 2, sx / 2, sy / 2
        b = len(self.pts)
        self.pts += [(cx - hx, cy - hy, z), (cx + hx, cy - hy, z), (cx + hx, cy + hy, z), (cx - hx, cy + hy, z)]
        self.faces.append([b, b + 1, b + 2, b + 3])

    def write(self, path):
        with open(path, 'w') as f:
            f.write('V1\n# 3D Points\n%d\n' % len(self.pts))
            for p in self.pts:
                f.write('%.5f %.5f %.5f\n' % p)
            f.write('# 3D Lines\n0\n# Faces from 3D lines\n0\n# Faces from 3D points\n%d\n' % len(self.faces))
            for fc in self.faces:
                f.write('%d %s\n' % (len(fc), ' '.join(map(str, fc))))
            f.write('# 3D cylinders\n0\n# 3D circles\n0\n')


def write_targets(path, cao_rel):
    screw_top = SCREW_Z + SCREW_H / 2
    targets = {}
    for i, (x, y) in enumerate(SCREW_XY, 1):
        targets[f'screw_{i}'] = dict(type='screw', xyz=[x, y, round(screw_top, 5)], rpy=[0.0, 0.0, 0.0],
                                     head_radius=SCREW_R, ring_radius=0.03, ring_points=4,
                                     standoff=0.15, approach_standoff=0.30)
    (px, py, pz), (sx, sy, sz) = PANEL['center'], PANEL['size']
    targets['solar_panel'] = dict(type='planar_region', xyz=[px, py, pz + sz / 2], rpy=[0.0, 0.0, 0.0],
                                  size=[sx, sy], standoff=0.40, approach_standoff=0.55)
    doc = {'model': {'cao_file': cao_rel}, 'targets': targets}
    with open(path, 'w') as f:
        f.write('# Servicing targets in the spacecraft MODEL frame (same frame as the .cao and the Gazebo model).\n'
                '# Target frame +Z = outward surface normal; the camera ends up on that normal at `standoff`.\n'
                '# Generated by tools/make_mock_spacecraft.py -- edit freely for the real model.\n')
        yaml.safe_dump(doc, f, sort_keys=False, default_flow_style=None)


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    mdir = os.path.join(root, 'models', 'mock_spacecraft')
    os.makedirs(mdir, exist_ok=True)
    write_sdf(os.path.join(mdir, 'model.sdf'))
    write_config(os.path.join(mdir, 'model.config'))
    cao = Cao()
    cao.box(BUS)
    cao.top_rectangle(PLATE)
    cao.box(PANEL)
    cao.write(os.path.join(mdir, 'spacecraft.cao'))
    write_targets(os.path.join(root, 'config', 'targets.yaml'), 'mock_spacecraft/spacecraft.cao')
    print('written:', mdir, 'and config/targets.yaml')


if __name__ == '__main__':
    main()
